# Lecture-to-Action Study Assistant

A Flask + SQLite final-year project that turns lecture transcripts into summaries, key points, action items, flashcards, and quiz questions. It includes account registration/login, a student dashboard, task completion, quiz scores, and downloadable text notes.

## Implemented in the base project (offline)
- Registration and login with Werkzeug password hashing.
- Per-user lecture and task storage in SQLite.
- Transcript-based extractive summary using term frequency and sentence ranking.
- Key-point extraction.
- Rule-based action-item detection and simple explicit deadline recognition.
- Definition-pattern / prompt-based flashcards.
- Quiz generation from lecture sentences and score tracking.
- Downloadable notes as `.txt`.

**Important:** The offline study engine uses transparent heuristics. It is not a large language model and its generated questions/flashcards can be imperfect. Review outputs before relying on them academically.

## Optional AI transcription
Audio transcription is optional because it needs either a cloud API or a local speech model.

### Option A: OpenAI transcription API
1. Install the optional package: `pip install openai`
2. Set `OPENAI_API_KEY` in your environment.
3. Start the app. Upload an MP3/WAV/M4A/MP4/WEBM/OGG file up to 30 MB.
4. API usage may incur charges. Keep the key private and do not commit it to source control.

Windows PowerShell:
```powershell
$env:OPENAI_API_KEY="your-key"
python app.py
```

macOS/Linux:
```bash
export OPENAI_API_KEY="your-key"
python app.py
```

### Option B: Local faster-whisper
1. Install: `pip install faster-whisper`
2. Set `LOCAL_WHISPER=1`.
3. Run the app. The selected model may download files on first use and can require substantial disk space and processing time.

Windows PowerShell:
```powershell
$env:LOCAL_WHISPER="1"
python app.py
```

If neither option is configured, the audio file is accepted only as an upload attempt; the app asks for a transcript rather than pretending it transcribed the audio. You can paste text in the transcript field in the same form.

## Setup
Python 3.10+ recommended.

### Windows
```powershell
py -m venv .venv
.venv\Scripts\Activate.ps1
pip install -r requirements.txt
python app.py
```

### macOS/Linux
```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
python app.py
```

Open http://127.0.0.1:5000 and create an account.

## Project structure
```text
lecture_to_action_assistant/
├── app.py
├── study_engine.py
├── requirements.txt
├── .env.example
├── README.md
├── data/
│   └── .gitkeep
├── static/
│   ├── css/style.css
│   └── js/app.js
└── templates/
    ├── base.html
    ├── landing.html
    ├── login.html
    ├── register.html
    ├── dashboard.html
    ├── new_lecture.html
    └── lecture_detail.html
```

## Security / deployment notes
- Change `SECRET_KEY` before deployment.
- Use HTTPS and secure cookie settings in production.
- Add CSRF protection, rate limiting, email verification, password reset, and stricter audio validation before public deployment.
- This is a student prototype, not a production security-reviewed service.
- Audio uploads are stored locally in `data/uploads`; implement retention/deletion controls for real users.
