import os
import re
import sqlite3
import secrets
from datetime import datetime
from functools import wraps
from pathlib import Path

from flask import Flask, render_template, request, redirect, url_for, session, flash, send_from_directory
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename

from study_engine import analyze_transcript, transcribe_audio

BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = BASE_DIR / "data"
UPLOAD_DIR = DATA_DIR / "uploads"
DB_PATH = DATA_DIR / "study_assistant.db"
ALLOWED_AUDIO = {"mp3", "wav", "m4a", "mp4", "webm", "ogg", "mpeg"}
MAX_CONTENT_LENGTH = 30 * 1024 * 1024

app = Flask(__name__)
app.config["SECRET_KEY"] = os.environ.get("SECRET_KEY", "change-this-dev-secret-before-deployment")
app.config["MAX_CONTENT_LENGTH"] = MAX_CONTENT_LENGTH
DATA_DIR.mkdir(exist_ok=True)
UPLOAD_DIR.mkdir(parents=True, exist_ok=True)


def db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


def init_db():
    with db() as conn:
        conn.executescript("""
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            email TEXT NOT NULL UNIQUE,
            password_hash TEXT NOT NULL,
            created_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS lectures (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            title TEXT NOT NULL,
            subject TEXT NOT NULL,
            transcript TEXT NOT NULL,
            summary TEXT NOT NULL,
            key_points TEXT NOT NULL,
            action_items TEXT NOT NULL,
            flashcards TEXT NOT NULL,
            quiz TEXT NOT NULL,
            source_type TEXT NOT NULL,
            created_at TEXT NOT NULL,
            FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
        );
        CREATE TABLE IF NOT EXISTS quiz_results (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            lecture_id INTEGER NOT NULL,
            score INTEGER NOT NULL,
            total INTEGER NOT NULL,
            created_at TEXT NOT NULL,
            FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE,
            FOREIGN KEY(lecture_id) REFERENCES lectures(id) ON DELETE CASCADE
        );
        CREATE TABLE IF NOT EXISTS tasks (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            lecture_id INTEGER NOT NULL,
            task_text TEXT NOT NULL,
            due_date TEXT,
            completed INTEGER NOT NULL DEFAULT 0,
            created_at TEXT NOT NULL,
            FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE,
            FOREIGN KEY(lecture_id) REFERENCES lectures(id) ON DELETE CASCADE
        );
        """)


def login_required(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        if "user_id" not in session:
            flash("Please log in to continue.", "info")
            return redirect(url_for("login"))
        return view(*args, **kwargs)
    return wrapped


def current_user():
    if "user_id" not in session:
        return None
    with db() as conn:
        return conn.execute("SELECT id, name, email FROM users WHERE id=?", (session["user_id"],)).fetchone()


def allowed_audio(filename):
    return "." in filename and filename.rsplit(".", 1)[1].lower() in ALLOWED_AUDIO


@app.route("/")
def index():
    if session.get("user_id"):
        return redirect(url_for("dashboard"))
    return render_template("landing.html")


@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        name = request.form.get("name", "").strip()
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")
        if not name or not email or len(password) < 8:
            flash("Enter your name and email. Password must be at least 8 characters.", "error")
            return render_template("register.html")
        try:
            with db() as conn:
                conn.execute(
                    "INSERT INTO users(name,email,password_hash,created_at) VALUES(?,?,?,?)",
                    (name, email, generate_password_hash(password), datetime.now().isoformat(timespec="seconds"))
                )
            flash("Account created. You can now log in.", "success")
            return redirect(url_for("login"))
        except sqlite3.IntegrityError:
            flash("An account with that email already exists.", "error")
    return render_template("register.html")


@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")
        with db() as conn:
            user = conn.execute("SELECT * FROM users WHERE email=?", (email,)).fetchone()
        if user and check_password_hash(user["password_hash"], password):
            session.clear()
            session["user_id"] = user["id"]
            session["user_name"] = user["name"]
            return redirect(url_for("dashboard"))
        flash("Incorrect email or password.", "error")
    return render_template("login.html")


@app.route("/logout")
def logout():
    session.clear()
    flash("You have been logged out.", "info")
    return redirect(url_for("index"))


@app.route("/dashboard")
@login_required
def dashboard():
    user = current_user()
    with db() as conn:
        lectures = conn.execute(
            "SELECT id,title,subject,created_at,source_type FROM lectures WHERE user_id=? ORDER BY id DESC LIMIT 6",
            (user["id"],)
        ).fetchall()
        lecture_count = conn.execute("SELECT COUNT(*) AS n FROM lectures WHERE user_id=?", (user["id"],)).fetchone()["n"]
        task_count = conn.execute("SELECT COUNT(*) AS n FROM tasks WHERE user_id=? AND completed=0", (user["id"],)).fetchone()["n"]
        completed_tasks = conn.execute("SELECT COUNT(*) AS n FROM tasks WHERE user_id=? AND completed=1", (user["id"],)).fetchone()["n"]
        avg = conn.execute("SELECT AVG(score * 100.0 / total) AS n FROM quiz_results WHERE user_id=? AND total>0", (user["id"],)).fetchone()["n"]
    return render_template("dashboard.html", user=user, lectures=lectures, lecture_count=lecture_count,
                           task_count=task_count, completed_tasks=completed_tasks,
                           average_score=round(avg) if avg is not None else None)


@app.route("/lectures/new", methods=["GET", "POST"])
@login_required
def new_lecture():
    if request.method == "POST":
        title = request.form.get("title", "").strip() or "Untitled lecture"
        subject = request.form.get("subject", "").strip() or "General"
        transcript = request.form.get("transcript", "").strip()
        audio = request.files.get("audio")
        source_type = "text"
        if audio and audio.filename:
            if not allowed_audio(audio.filename):
                flash("Unsupported audio type. Use MP3, WAV, M4A, MP4, WEBM, OGG, or MPEG.", "error")
                return render_template("new_lecture.html")
            safe_name = secure_filename(audio.filename)
            stored_name = f"{secrets.token_hex(8)}_{safe_name}"
            path = UPLOAD_DIR / stored_name
            audio.save(path)
            try:
                audio_text, method = transcribe_audio(path)
                if audio_text.strip():
                    transcript = (transcript + "\n\n" + audio_text).strip() if transcript else audio_text.strip()
                    source_type = f"audio ({method})"
                elif not transcript:
                    flash("Audio was uploaded, but transcription is not configured. Paste a transcript or configure optional transcription.", "error")
                    return render_template("new_lecture.html")
                else:
                    source_type = "audio + text"
            except Exception as exc:
                app.logger.exception("Audio transcription failed")
                if not transcript:
                    flash(f"Audio transcription failed: {str(exc)[:180]}. You can paste a transcript instead.", "error")
                    return render_template("new_lecture.html")
                source_type = "audio + text"
        if len(transcript) < 30:
            flash("Please provide a transcript of at least 30 characters, or upload audio with transcription configured.", "error")
            return render_template("new_lecture.html")
        result = analyze_transcript(transcript)
        created = datetime.now().isoformat(timespec="seconds")
        with db() as conn:
            cur = conn.execute("""
                INSERT INTO lectures(user_id,title,subject,transcript,summary,key_points,action_items,flashcards,quiz,source_type,created_at)
                VALUES(?,?,?,?,?,?,?,?,?,?,?)
            """, (session["user_id"], title, subject, transcript, result["summary"],
                  json_dumps(result["key_points"]), json_dumps(result["action_items"]),
                  json_dumps(result["flashcards"]), json_dumps(result["quiz"]), source_type, created))
            lecture_id = cur.lastrowid
            for item in result["action_items"]:
                conn.execute("INSERT INTO tasks(user_id,lecture_id,task_text,due_date,created_at) VALUES(?,?,?,?,?)",
                             (session["user_id"], lecture_id, item["task"], item.get("due_date"), created))
        flash("Lecture processed and study materials generated.", "success")
        return redirect(url_for("lecture_detail", lecture_id=lecture_id))
    return render_template("new_lecture.html")


def json_dumps(value):
    import json
    return json.dumps(value, ensure_ascii=False)


def json_loads(value):
    import json
    try:
        return json.loads(value)
    except (ValueError, TypeError):
        return []


@app.route("/lectures/<int:lecture_id>")
@login_required
def lecture_detail(lecture_id):
    with db() as conn:
        lecture = conn.execute("SELECT * FROM lectures WHERE id=? AND user_id=?",
                               (lecture_id, session["user_id"])).fetchone()
        if not lecture:
            flash("Lecture not found.", "error")
            return redirect(url_for("dashboard"))
        tasks = conn.execute("SELECT * FROM tasks WHERE lecture_id=? AND user_id=? ORDER BY completed,due_date",
                             (lecture_id, session["user_id"])).fetchall()
        results = conn.execute("SELECT * FROM quiz_results WHERE lecture_id=? AND user_id=? ORDER BY id DESC LIMIT 5",
                               (lecture_id, session["user_id"])).fetchall()
    return render_template("lecture_detail.html", lecture=lecture,
                           key_points=json_loads(lecture["key_points"]),
                           action_items=json_loads(lecture["action_items"]),
                           flashcards=json_loads(lecture["flashcards"]),
                           quiz=json_loads(lecture["quiz"]), tasks=tasks, results=results)


@app.route("/tasks/<int:task_id>/toggle", methods=["POST"])
@login_required
def toggle_task(task_id):
    with db() as conn:
        task = conn.execute("SELECT * FROM tasks WHERE id=? AND user_id=?", (task_id, session["user_id"])).fetchone()
        if task:
            conn.execute("UPDATE tasks SET completed=? WHERE id=? AND user_id=?",
                         (0 if task["completed"] else 1, task_id, session["user_id"]))
            flash("Task status updated.", "success")
    return redirect(request.referrer or url_for("dashboard"))


@app.route("/lectures/<int:lecture_id>/quiz", methods=["POST"])
@login_required
def submit_quiz(lecture_id):
    answers = request.form
    with db() as conn:
        lecture = conn.execute("SELECT * FROM lectures WHERE id=? AND user_id=?",
                               (lecture_id, session["user_id"])).fetchone()
        if not lecture:
            flash("Lecture not found.", "error")
            return redirect(url_for("dashboard"))
        quiz = json_loads(lecture["quiz"])
        total = len(quiz)
        score = sum(1 for i, q in enumerate(quiz) if answers.get(f"q{i}") == str(q["answer_index"]))
        conn.execute("INSERT INTO quiz_results(user_id,lecture_id,score,total,created_at) VALUES(?,?,?,?,?)",
                     (session["user_id"], lecture_id, score, total, datetime.now().isoformat(timespec="seconds")))
    flash(f"Quiz submitted: {score}/{total}. Review the answer key on the lecture page.", "success")
    return redirect(url_for("lecture_detail", lecture_id=lecture_id))


@app.route("/lectures/<int:lecture_id>/download")
@login_required
def download_notes(lecture_id):
    with db() as conn:
        lecture = conn.execute("SELECT * FROM lectures WHERE id=? AND user_id=?",
                               (lecture_id, session["user_id"])).fetchone()
    if not lecture:
        flash("Lecture not found.", "error")
        return redirect(url_for("dashboard"))
    content = f"{lecture['title']}\nSubject: {lecture['subject']}\nCreated: {lecture['created_at']}\n\nSUMMARY\n{lecture['summary']}\n\nKEY POINTS\n"
    for point in json_loads(lecture["key_points"]):
        content += f"- {point}\n"
    content += "\nACTION ITEMS\n"
    for item in json_loads(lecture["action_items"]):
        content += f"- {item['task']}" + (f" (Due: {item['due_date']})" if item.get("due_date") else "") + "\n"
    content += "\nFLASHCARDS\n"
    for card in json_loads(lecture["flashcards"]):
        content += f"Q: {card['question']}\nA: {card['answer']}\n\n"
    response_name = f"lecture_{lecture_id}_notes.txt"
    out_dir = DATA_DIR / "exports"
    out_dir.mkdir(exist_ok=True)
    (out_dir / response_name).write_text(content, encoding="utf-8")
    return send_from_directory(out_dir, response_name, as_attachment=True)


@app.errorhandler(413)
def too_large(_error):
    flash("File is too large. Maximum upload size is 30 MB.", "error")
    return redirect(url_for("new_lecture"))


init_db()

if __name__ == "__main__":
    app.run(debug=True)
