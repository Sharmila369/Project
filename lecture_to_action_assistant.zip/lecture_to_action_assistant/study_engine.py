"""Study-material engine.

Implemented offline features:
- sentence scoring and extractive summaries
- key-point extraction
- rule-based action-item detection and explicit date recognition
- definition-pattern flashcards
- quiz questions from extracted key sentences

Optional AI:
- audio transcription with OpenAI's API when OPENAI_API_KEY is configured
- local transcription using faster-whisper if installed and LOCAL_WHISPER=1
The offline text analysis is heuristic NLP, not a generative LLM.
"""
import os
import re
from collections import Counter
from pathlib import Path

STOPWORDS = set("""
a an the and or but if then than so because while of at by for with about against between into through
during before after above below to from up down in out on off over under again further once here there
when where why how all any both each few more most other some such no nor not only own same so than too
very can will just should now is am are was were be been being have has had do does did this that these
those it its as we you your they their he she his her them our us i me my who which what also lecture
students student teacher topic concept example use used using may might must would could
""".split())


def clean_text(text):
    return re.sub(r"\s+", " ", (text or "")).strip()


def split_sentences(text):
    text = clean_text(text)
    if not text:
        return []
    return [s.strip() for s in re.split(r"(?<=[.!?])\s+(?=[A-Z0-9\"'])", text) if len(s.strip()) > 15]


def tokenize(text):
    return re.findall(r"[A-Za-z][A-Za-z'-]{2,}", text.lower())


def summarize(text, max_sentences=5):
    sentences = split_sentences(text)
    if len(sentences) <= max_sentences:
        return " ".join(sentences) or clean_text(text)[:700]
    words = [w for w in tokenize(text) if w not in STOPWORDS]
    frequencies = Counter(words)
    max_freq = max(frequencies.values(), default=1)
    weights = {w: count / max_freq for w, count in frequencies.items()}
    scored = []
    for idx, sentence in enumerate(sentences):
        terms = [w for w in tokenize(sentence) if w not in STOPWORDS]
        score = sum(weights.get(w, 0) for w in terms) / max(len(terms), 1)
        # Slight preference for early sentences, common in lecture introductions.
        score += max(0, 0.12 - idx * 0.01)
        scored.append((score, idx, sentence))
    chosen = sorted(sorted(scored, reverse=True)[:max_sentences], key=lambda x: x[1])
    return " ".join(s for _, _, s in chosen)


def key_points(text, limit=8):
    sentences = split_sentences(text)
    if not sentences:
        return [clean_text(text)[:250]] if clean_text(text) else []
    summary = summarize(text, max_sentences=min(limit, 6))
    points = [s for s in split_sentences(summary) if s]
    # Keep the most useful points and avoid overlong bullet items.
    return [p if len(p) <= 300 else p[:297].rsplit(" ", 1)[0] + "..." for p in points[:limit]]


def extract_actions(text):
    sentences = split_sentences(text)
    trigger = re.compile(r"\b(please|must|need to|remember to|submit|complete|finish|prepare|revise|review|read|study|upload|bring|assignment|homework|deadline|due)\b", re.I)
    date_pattern = re.compile(r"\b(by|before|on)\s+((?:Monday|Tuesday|Wednesday|Thursday|Friday|Saturday|Sunday|tomorrow|today|next week|next Monday|next Tuesday|next Wednesday|next Thursday|next Friday|next Saturday|next Sunday)|\d{1,2}(?:st|nd|rd|th)?\s+(?:January|February|March|April|May|June|July|August|September|October|November|December))\b", re.I)
    actions = []
    seen = set()
    for sentence in sentences:
        if trigger.search(sentence):
            task = sentence.strip()
            due = None
            match = date_pattern.search(sentence)
            if match:
                due = match.group(2)
            key = task.lower()
            if key not in seen:
                actions.append({"task": task, "due_date": due})
                seen.add(key)
        if len(actions) >= 10:
            break
    return actions


def make_flashcards(text, points):
    cards = []
    # Detect simple explicit definitions: "X is/are ..." and "X refers to ..."
    patterns = [
        re.compile(r"\b([A-Z][A-Za-z0-9 -]{2,45})\s+(?:is|are|refers to|means|is defined as)\s+([^.!?]{15,180})[.!?]", re.I),
        re.compile(r"\b([A-Z][A-Za-z0-9 -]{2,45})\s*:\s*([^.!?]{15,180})[.!?]")
    ]
    for pattern in patterns:
        for match in pattern.finditer(text):
            term, definition = match.group(1).strip(), match.group(2).strip()
            if len(term.split()) <= 7 and len(definition.split()) >= 3:
                cards.append({"question": f"What is {term}?", "answer": definition.rstrip(" ,;")})
                if len(cards) >= 8:
                    return dedupe_cards(cards)
    for point in points:
        words = tokenize(point)
        if len(words) >= 8:
            # Cloze-style prompt; answer is a short extract from the point.
            key_terms = [w for w in words if w not in STOPWORDS]
            if key_terms:
                term = max(set(key_terms), key=key_terms.count)
                cards.append({"question": f"Explain the role of '{term}' in this lecture.", "answer": point})
        if len(cards) >= 6:
            break
    return dedupe_cards(cards)[:8]


def dedupe_cards(cards):
    out, seen = [], set()
    for card in cards:
        key = card["question"].lower()
        if key not in seen:
            seen.add(key)
            out.append(card)
    return out


def make_quiz(points):
    quiz = []
    for point in points[:6]:
        words = [w for w in re.findall(r"\b[A-Za-z][A-Za-z'-]{3,}\b", point) if w.lower() not in STOPWORDS]
        if len(words) < 3:
            continue
        answer = max(set(words), key=words.count)
        # Avoid generating awkward one-word questions from extremely short statements.
        question = re.sub(re.escape(answer), "________", point, count=1, flags=re.I)
        distractors = []
        for candidate in ["database", "process", "system", "method", "information", "structure", "analysis", "model"]:
            if candidate.lower() != answer.lower() and candidate.lower() not in point.lower() and candidate not in distractors:
                distractors.append(candidate)
            if len(distractors) == 3:
                break
        options = [answer] + distractors
        # Deterministic rotation prevents the correct answer always appearing first.
        rotation = len(quiz) % len(options)
        options = options[rotation:] + options[:rotation]
        quiz.append({"question": question, "options": options, "answer_index": options.index(answer),
                     "explanation": point})
    return quiz[:6]


def analyze_transcript(text):
    text = clean_text(text)
    points = key_points(text)
    actions = extract_actions(text)
    flashcards = make_flashcards(text, points)
    quiz = make_quiz(points)
    return {
        "summary": summarize(text),
        "key_points": points,
        "action_items": actions,
        "flashcards": flashcards,
        "quiz": quiz
    }


def transcribe_audio(path):
    """Return (transcript, method). API transcription is optional."""
    api_key = os.environ.get("OPENAI_API_KEY")
    if api_key:
        try:
            from openai import OpenAI
            client = OpenAI(api_key=api_key)
            with open(path, "rb") as audio_file:
                result = client.audio.transcriptions.create(model=os.environ.get("OPENAI_TRANSCRIPTION_MODEL", "whisper-1"),
                                                            file=audio_file)
            return result.text, "OpenAI API"
        except ImportError:
            raise RuntimeError("OPENAI_API_KEY is set but the optional 'openai' package is not installed. Run: pip install openai")
    if os.environ.get("LOCAL_WHISPER", "0") == "1":
        try:
            from faster_whisper import WhisperModel
            model = WhisperModel(os.environ.get("WHISPER_MODEL_SIZE", "base"), device="cpu", compute_type="int8")
            segments, _info = model.transcribe(str(path), vad_filter=True)
            return " ".join(segment.text.strip() for segment in segments), "local faster-whisper"
        except ImportError:
            raise RuntimeError("LOCAL_WHISPER=1 but faster-whisper is not installed. Run: pip install faster-whisper")
    return "", "not configured"
