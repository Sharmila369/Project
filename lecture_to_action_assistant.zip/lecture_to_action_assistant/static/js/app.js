document.addEventListener("DOMContentLoaded", () => {
  const fileInput = document.getElementById("audio-file");
  const fileName = document.getElementById("file-name");
  if (fileInput && fileName) {
    fileInput.addEventListener("change", () => {
      fileName.textContent = fileInput.files && fileInput.files.length
        ? `Selected: ${fileInput.files[0].name}` : "";
    });
  }
  document.querySelectorAll("[data-flashcard]").forEach(card => {
    card.addEventListener("click", () => card.classList.toggle("revealed"));
  });
});
